import sys
import cv2
import numpy as np

font = cv2.FONT_HERSHEY_SIMPLEX

def mouse_callback(event,x,y,flags,param):
    r = img[y][x][2]
    g = img[y][x][1]
    b = img[y][x][0]
    h = hsv[y][x][0]
    s = hsv[y][x][1]
    v = hsv[y][x][2]
    output_rgb = "R:%d, G:%d, B:%d " % (r, g, b)
    output_hsv = "H:%d, S:%d, V:%d " % (h, s, v)
    tmp = img.copy()
    cv2.putText(tmp,output_rgb, (10,20), font, 0.5, (0,0,0))
    cv2.putText(tmp,output_hsv, (10,40), font, 0.5, (0,0,0))
    cv2.imshow('window',tmp)
    if event == cv2.EVENT_LBUTTONDOWN:
        print "hsv: (%d, %d, %d)        BGR:  (%d, %d, %d) " % (h,s,v,b,g,r)


def draw_blue ():
    lower_blue = np.array([109, 80, 120])
    upper_blue = np.array([135, 255, 220])
    blue = cv2.inRange(hsv, lower_blue, upper_blue)
#    cv2.imshow('blue', blue) 
    kernel = np.ones((3,3),np.uint8)
    blue_erosion = cv2.erode(blue,kernel,iterations = 1)
    blue_dilation = cv2.dilate(blue_erosion,kernel,iterations = 1)
#    cv2.imshow('Blue Dilation',blue_dilation)
    _, contours, _= cv2.findContours(blue_dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
#    cv2.drawContours(img, contours, -1, (0,255,0), 3)

    i = 0
    while i < len(contours):
        cnt = contours[i]
        rect = cv2.minAreaRect(cnt)
        x = rect[0][0]
        y = rect[0][1]
#        cv2.putText(img,"%.2f, %.2f" % (x,y),(int(x) - 70,int(y) - 20),font, 0.5, (0,255,0),1)
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        cv2.drawContours(img,[box],0,(0,255,0),2)
        i = i +1



def draw_red():
    lower_red1 = np.array([176, 120, 130])
    upper_red1 = np.array([180, 255, 255])
    lower_red2 = np.array([0, 50, 130])
    upper_red2 = np.array([8, 255, 210])
    lower_red3 = np.array([170, 50, 130])
    upper_red3 = np.array([178, 255, 190])
    red = cv2.inRange(hsv, lower_red1, upper_red1) + cv2.inRange(hsv, lower_red2, upper_red2) + cv2.inRange(hsv, lower_red3, upper_red3) 
    #cv2.imshow('red', red)
    kernel = np.ones((3,3),np.uint8)
    red_erosion = cv2.erode(red,kernel,iterations = 2)
    red_dilation = cv2.dilate(red_erosion,kernel,iterations = 3)
    #cv2.imshow('Red Dilation',red_dilation)
    _, contours, _= cv2.findContours(red_dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
#    cv2.drawContours(img, contours, -1, (0,255,0), 3)
    
    i = 0
    while i < len(contours):
        cnt = contours[i]
        rect = cv2.minAreaRect(cnt)
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        cv2.drawContours(img,[box],0,(0,255,0),2)
        i = i +1
        
def draw_purple():
    lower_purple = np.array([150, 90, 85])
    upper_purple = np.array([170, 200, 170])
    purple = cv2.inRange(hsv, lower_purple, upper_purple)
    #cv2.imshow('purple', purple)
    kernel = np.ones((3,3),np.uint8)
    purple_erosion = cv2.erode(purple,kernel,iterations = 1)
    purple_dilation = cv2.dilate(purple_erosion,kernel,iterations = 2)
    #cv2.imshow('Purple Dilation',purple_dilation)
    _, contours, _= cv2.findContours(purple_dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
#    cv2.drawContours(img, contours, -1, (0,255,0), 3)
    
    i = 0
    while i < len(contours):
        cnt = contours[i]
        rect = cv2.minAreaRect(cnt)
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        cv2.drawContours(img,[box],0,(0,255,0),2)
        i = i +1
        
def draw_green():
    lower_green = np.array([35, 0, 85])
    upper_green = np.array([95, 130, 255])
    green = cv2.inRange(hsv, lower_green, upper_green)
    #cv2.imshow('green', green)
    kernel = np.ones((3,3),np.uint8)
    green_erosion = cv2.erode(green,kernel,iterations = 1)
    green_dilation = cv2.dilate(green_erosion,kernel,iterations = 2)
    #cv2.imshow('Green Dilation',green_dilation)
    _, contours, _= cv2.findContours(green_dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
#    cv2.drawContours(img, contours, -1, (0,255,0), 3)

    i = 0
    while i < len(contours):
        cnt = contours[i]
        rect = cv2.minAreaRect(cnt)
        box = cv2.boxPoints(rect)
        box = np.int0(box)
#        cv2.drawContours(img,[box],0,(0,255,0),2)
        i = i +1
        
        
def draw_yellow():
    lower_yellow = np.array([20, 60, 230])
    upper_yellow = np.array([35, 254, 254])
    yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)
    #cv2.imshow('yellow', yellow)
    kernel = np.ones((3,3),np.uint8)
    yellow_erosion = cv2.erode(yellow,kernel,iterations = 1)
    yellow_dilation = cv2.dilate(yellow_erosion,kernel,iterations = 2)
    #cv2.imshow('yellow Dilation',yellow_dilation)
    _, contours, _= cv2.findContours(yellow_dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
#    cv2.drawContours(img, contours, -1, (0,255,0), 3)

    i = 0
    while i < len(contours):
        cnt = contours[i]
        rect = cv2.minAreaRect(cnt)
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        cv2.drawContours(img,[box],0,(0,255,0),2)
        i = i +1
        
        
def draw_black():
    lower_black = np.array([125, 15, 15])
    upper_black = np.array([175, 90, 50])
    black = cv2.inRange(hsv, lower_black, upper_black)
#    cv2.imshow('black', black)
    kernel = np.ones((5,5),np.uint8)
    black_erosion = cv2.erode(black,kernel,iterations = 1)
    black_dilation = cv2.dilate(black_erosion,kernel,iterations = 2)
#    cv2.imshow('Black Dilation',black_dilation)
    _, contours, _= cv2.findContours(black_dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(img, contours, -1, (0,255,0), 3)

def draw_orange():
    lower_orange = np.array([5, 100, 170])
    upper_orange = np.array([20, 255, 255])
    orange = cv2.inRange(hsv, lower_orange, upper_orange)
    #cv2.imshow('orange', orange)
    kernel = np.ones((3,3),np.uint8)
    orange_erosion = cv2.erode(orange,kernel,iterations = 1)
    orange_dilation = cv2.dilate(orange_erosion,kernel,iterations = 1)
    #cv2.imshow('Orange Dilation',orange_dilation)
    _, contours, _= cv2.findContours(orange_dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
#    cv2.drawContours(img, contours, -1, (0,255,0), 3)
#
    i = 0
    while i < len(contours):
        cnt = contours[i]
        rect = cv2.minAreaRect(cnt)
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        cv2.drawContours(img,[box],0,(0,255,0),2)
        i = i +1

def draw_pink():
    lower_pink2 = np.array([70, 25, 170])
    upper_pink2 = np.array([115, 70, 240])
    pink = cv2.inRange(img, lower_pink2, upper_pink2)
#    cv2.imshow('pink', pink)
    kernel = np.ones((3,3),np.uint8)
    pink_erosion = cv2.erode(pink,kernel,iterations = 1)
    pink_dilation = cv2.dilate(pink_erosion,kernel,iterations = 1)
#    cv2.imshow('pink Dilation',pink_dilation)
    _, contours, _= cv2.findContours(pink_dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
#    cv2.drawContours(img, contours, -1, (0,255,0), 3)
    #lower_pink = np.array([160, 160, 170])
    #upper_pink = np.array([180, 220, 230])
    #lower_pink2 = np.array([75, 25, 175])
    #upper_pink2 = np.array([115, 70, 240])
    #pink = cv2.inRange(hsv, lower_pink, upper_pink) +  cv2.inRange(img, lower_pink2, upper_pink2)
    #cv2.imshow('pink', pink)
    #kernel = np.ones((3,3),np.uint8)
    #pink_erosion = cv2.erode(pink,kernel,iterations = 1)
    #pink_dilation = cv2.dilate(pink_erosion,kernel,iterations = 1)
    ##cv2.imshow('pink Dilation',pink_dilation)
    #_, contours, _= cv2.findContours(pink_dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    #cv2.drawContours(img, contours, -1, (0,255,0), 3)

    i = 0
    while i < len(contours):
        cnt = contours[i]
        rect = cv2.minAreaRect(cnt)
        box = cv2.boxPoints(rect)
        box = np.int0(box)
        cv2.drawContours(img,[box],0,(0,255,0),2)
        i = i +1
    
print "Opening pictue"
img = cv2.imread('D:/School/550 Robotics/OpenCV_pics/BadLight.png',cv2.IMREAD_UNCHANGED)
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
#gray = cv2.cvtColor(img, cv2.COLOR_BGR2RGBA)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)

cv2.namedWindow("window",1)
cv2.imshow('window', img)
cv2.setMouseCallback("window",mouse_callback)
#cv2.namedWindow("window",cv2.WINDOW_AUTOSIZE)
#cv2.imshow('window', img)
#cv2.imshow('window2', gray)
#draw_blue()
draw_red()
#draw_pink()
#draw_purple()
#draw_green()
#draw_orange()
#draw_yellow()
#draw_black()






#opening = cv2.morphologyEx(blue, cv2.MORPH_OPEN, kernel)
#cv2.imshow('opening',opening)

#closing = cv2.morphologyEx(erosion, cv2.MORPH_CLOSE, kernel)
#cv2.imshow('closing',closing)
#


#_, contours, _= cv2.findContours(dilation, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
#
#cv2.drawContours(img, contours, -1, (0,255,0), 3)
#cnt = contours[4]
#cv2.drawContours(img, [cnt], 0, (0,255,0), 3)



while True:
	ch = 0xFF & cv2.waitKey(10)
	if ch == 0x1B:
    	    break
cv2.destroyAllWindows()

